// Frontend del módulo de Buses.
// Se comunica con la API REST real (/api/buses) usando fetch. No hay datos de ejemplo.
// Recorrido: formulario -> fetch -> BusControlador -> BusNegocio -> BusDAO -> PostgreSQL -> respuesta -> tabla.

const URL_API = "/api/buses";

const formulario = document.getElementById("formulario");
const campoId = document.getElementById("id");
const campoPlaca = document.getElementById("placa");
const campoModelo = document.getElementById("modelo");
const campoCapacidad = document.getElementById("capacidad");
const campoEstado = document.getElementById("estado");
const btnGuardar = document.getElementById("btnGuardar");
const btnCancelar = document.getElementById("btnCancelar");
const tabla = document.getElementById("tabla");
const mensaje = document.getElementById("mensaje");

async function tokenCsrf() {
    const respuesta = await fetch("/api/auth/csrf");
    if (!respuesta.ok) {
        throw new Error("No se pudo validar la sesión");
    }
    return (await respuesta.json()).token;
}

function mostrarMensaje(texto, esError) {
    mensaje.textContent = texto;
    mensaje.className = esError ? "error" : "ok";
}

// Si el backend respondió con error, lee el texto {"error": "..."} y lo muestra.
async function textoDeError(respuesta) {
    try {
        const datos = await respuesta.json();
        return datos.error || "Error " + respuesta.status;
    } catch (e) {
        return "Error " + respuesta.status;
    }
}

// GET /api/buses -> dibuja la tabla con los buses guardados en PostgreSQL
async function cargarBuses() {
    try {
        const respuesta = await fetch("/api/buses");
        if (!respuesta.ok) {
            mostrarMensaje("Error al obtener buses", true);
            return;
        }
        const buses = await respuesta.json();
        dibujarTabla(buses);
    } catch (e) {
        mostrarMensaje("No se pudo conectar con el servidor", true);
    }
}

function dibujarTabla(buses) {
    const tabla = document.getElementById("tabla");
    tabla.innerHTML = "";

    // Validar si la lista está vacía
    if (!buses || buses.length === 0) {
        tabla.innerHTML = "<tr><td colspan='6' class='text-center text-muted'>No hay buses registrados.</td></tr>";
        return;
    }
    
    buses.forEach(function (bus) {
        try {
            const fila = document.createElement("tr");

            // Protección contra valores nulos en la base de datos
            let estadoTexto = bus.estado ? bus.estado.toUpperCase() : "DESCONOCIDO";
            let estadoColor = estadoTexto === 'ACTIVO' ? 'bg-success' : 
                              estadoTexto === 'MANTENIMIENTO' ? 'bg-warning text-dark' : 'bg-secondary';

            fila.innerHTML = `
                <td>${bus.id || '-'}</td>
                <td class="fw-bold">${bus.placa || '-'}</td>
                <td>${bus.modelo || '-'}</td>
                <td>${bus.capacidad || '-'}</td> 
                <td><span class="badge ${estadoColor}">${estadoTexto}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary me-1 btn-editar" data-id="${bus.id}">
                        <i class="bi bi-pencil"></i> Editar
                    </button>
                    <button class="btn btn-sm btn-outline-danger btn-eliminar" data-id="${bus.id}">
                        <i class="bi bi-trash"></i> Eliminar
                    </button>
                </td>
            `;
            tabla.appendChild(fila);
        } catch(error) {
            console.error("Error al procesar el bus con ID: " + bus.id, error);
        }
    });

    // Asignar los clics a los botones de forma segura
    document.querySelectorAll('.btn-editar').forEach(btn => {
        btn.addEventListener('click', function() {
            const busId = parseInt(this.getAttribute('data-id'));
            const bus = buses.find(b => b.id === busId);
            if (bus) prepararEdicion(bus);
        });
    });

    document.querySelectorAll('.btn-eliminar').forEach(btn => {
        btn.addEventListener('click', function() {
            const busId = parseInt(this.getAttribute('data-id'));
            eliminarBus(busId);
        });
    });
}

// Al enviar el formulario: si hay id es una edición (PUT), si no es un registro nuevo (POST)
formulario.addEventListener("submit", async function (evento) {
    evento.preventDefault();

    const bus = {
        placa: campoPlaca.value,
        modelo: campoModelo.value,
        capacidad: parseInt(campoCapacidad.value),
        estado: campoEstado.value
    };

    const editando = campoId.value !== "";
    const url = editando ? URL_API + "/" + campoId.value : URL_API;
    const metodo = editando ? "PUT" : "POST";

    try {
        const respuesta = await fetch(url, {
            method: metodo,
            headers: {
                "Content-Type": "application/json",
                "X-XSRF-TOKEN": await tokenCsrf()
            },
            body: JSON.stringify(bus)
        });

        if (!respuesta.ok) {
            mostrarMensaje(await textoDeError(respuesta), true);
            return;
        }

        limpiarFormulario();
        await cargarBuses(editando ? "Bus actualizado" : "Bus registrado");
    } catch (e) {
        mostrarMensaje("No se pudo conectar con el servidor", true);
    }
});

// DELETE /api/buses/{id}
async function eliminarBus(id) {
    if (!confirm("¿Eliminar el bus " + id + "?")) {
        return;
    }
    try {
        const respuesta = await fetch(URL_API + "/" + id, {
            method: "DELETE",
            headers: { "X-XSRF-TOKEN": await tokenCsrf() }
        });
        if (respuesta.status === 204) {
            await cargarBuses("Bus eliminado");
        } else {
            mostrarMensaje(await textoDeError(respuesta), true);
        }
    } catch (e) {
        mostrarMensaje("No se pudo conectar con el servidor", true);
    }
}

// Pone los datos del bus en el formulario para editarlos
function prepararEdicion(bus) {
    campoId.value = bus.id;
    campoPlaca.value = bus.placa;
    campoModelo.value = bus.modelo;
    campoCapacidad.value = bus.capacidad;
    campoEstado.value = bus.estado;
    btnGuardar.textContent = "Guardar cambios";
    btnCancelar.hidden = false;
}

function limpiarFormulario() {
    formulario.reset();
    campoId.value = "";
    btnGuardar.textContent = "Registrar bus";
    btnCancelar.hidden = true;
}

btnCancelar.addEventListener("click", limpiarFormulario);

// Al abrir la página se cargan los buses
cargarBuses();
